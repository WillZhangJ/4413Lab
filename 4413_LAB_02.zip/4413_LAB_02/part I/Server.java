import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class Server {
    public static void main(String[] args) throws Exception {
        // Check if port number is provided as a command line argument
        if (args.length < 1) {
            System.out.println("Usage: java Server <port>");
            System.exit(1);
        }

        int port = Integer.parseInt(args[0]);

        ServerSocket welcomeSocket = new ServerSocket(port);

        System.out.println("Server started on port " + port);

        while (true) {
            Socket connectionSocket = welcomeSocket.accept();
            System.out.println("Client connected: " + connectionSocket.getInetAddress().getHostAddress());

            // Create a new thread to handle the client connection
            ClientHandler clientHandler = new ClientHandler(connectionSocket);
            clientHandler.start();
        }
    }

    static class ClientHandler extends Thread {
        private final Socket connectionSocket;

        public ClientHandler(Socket connectionSocket) {
            this.connectionSocket = connectionSocket;
        }

        @Override
        public void run() {
            try {
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
                ObjectOutputStream outToClient = new ObjectOutputStream(connectionSocket.getOutputStream());

                String clientMessage;
                List<String> lines = new ArrayList<>();
                boolean isCalculating = false;

                while ((clientMessage = inFromClient.readLine()) != null) {
                    if (clientMessage.startsWith("array")) {
                        isCalculating = true;
                        lines.add(clientMessage);
                    } else {
                        if (isCalculating) {
                            break;  // Stop reading lines after 'array' line
                        }
                        lines.add(clientMessage.toUpperCase());
                    }
                }

                System.out.println("Received message from client: " + lines);

                if (isCalculating) {
                    List<Integer> numbers = new ArrayList<>();
                    String[] numberStrings = lines.get(lines.size() - 1).split(" ");
                    for (int i = 1; i < numberStrings.length; i++) {
                        numbers.add(Integer.parseInt(numberStrings[i]));
                    }

                    int sum = 0;
                    int max = Integer.MIN_VALUE;
                    for (int num : numbers) {
                        sum += num;
                        max = Math.max(max, num);
                    }

                    // Create maxsumResults object
                    MaxSumResults result = new MaxSumResults(sum, max);

                    // Send the result object to the client
                    outToClient.writeObject(result);
                }

                connectionSocket.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    static class MaxSumResults implements Serializable {
        private final int sum;
        private final int max;

        public MaxSumResults(int sum, int max) {
            this.sum = sum;
            this.max = max;
        }

        public int getSum() {
            return sum;
        }

        public int getMax() {
            return max;
        }
    }
}
