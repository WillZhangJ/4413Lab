import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;


public class Client {
    public static void main(String[] args) {
        // Check if host name and port number are provided as command line arguments
        if (args.length < 2) {
            System.out.println("Usage: java Client <host> <port>");
            System.exit(1);
        }

        String host = args[0];
        int port = Integer.parseInt(args[1]);

        try {
            Socket clientSocket = new Socket(host, port);

            BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());

            String userInput;
            while ((userInput = inFromUser.readLine()) != null) {
                outToServer.writeBytes(userInput + '\n');

                String serverResponse = inFromServer.readLine();
                System.out.println("FROM SERVER: " + serverResponse);

                if (userInput.startsWith("array")) {
                    // Receive the result object from the server
                    MaxSumResults result = (MaxSumResults) new ObjectInputStream(clientSocket.getInputStream()).readObject();

                    System.out.println("sum: " + result.getSum());
                    System.out.println("max: " + result.getMax());

                    break; // Stop sending lines after receiving the result
                }
            }

            clientSocket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
