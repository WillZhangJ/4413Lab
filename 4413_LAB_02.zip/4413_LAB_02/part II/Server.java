import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;

/**************************************************************************
 client connects to server, sends to server REGISTER, QUERY or QUIT message
 for QUERY, the server will search its Table database and return the search result
****************************************************************************/

public class Server {
    public static void main(String[] args) throws Exception {
        // Check if port number is provided as a command line argument
        if (args.length < 1) {
            System.out.println("Usage: java Server <port>");
            System.exit(1);
        }

        int port = Integer.parseInt(args[0]);

        ServerSocket welcomeSocket = new ServerSocket(port);

        System.out.println("Server ready, waiting for connections...");

        Table table = new Table(); // Create a shared Table instance

        while (true) {
            Socket connectionSocket = welcomeSocket.accept();
            System.out.println("Client connected: " + connectionSocket.getInetAddress().getHostAddress());

            // Create a new thread to handle the client connection
            ClientHandler clientHandler = new ClientHandler(connectionSocket, table);
            clientHandler.start();
        }
    }
}

class ClientHandler extends Thread {
    private final Socket connectionSocket;
    private final Table table;

    public ClientHandler(Socket connectionSocket, Table table) {
        this.connectionSocket = connectionSocket;
        this.table = table;
    }

    @Override
    public void run() {
        try {
            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
            DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());

            String clientMessage;
            while ((clientMessage = inFromClient.readLine()) != null) {
                String response = processCommand(clientMessage);
                outToClient.writeBytes(response + '\n');
            }

            // Client disconnected, remove its record from the table
            table.quit(connectionSocket);

            connectionSocket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String processCommand(String command) {
        String[] tokens = command.split(" ");

        if (tokens.length < 2) {
            return "invalid command!";
        }

        String action = tokens[0];
        String name = tokens[1];

        switch (action) {
            case "register":
                if (tokens.length < 3) {
                    return "invalid command!";
                }
                String group = tokens[2];
                return table.register(name, group);
            case "query":
                if (tokens.length < 3) {
                    return "invalid command!";
                }
                String queryGroup = tokens[2];
                return table.query(queryGroup);
            case "quit":
                return table.quit(connectionSocket);
            default:
                return "invalid command!";
        }
    }
}
