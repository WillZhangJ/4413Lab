import java.io.*;
import java.net.*;

public class JavaHTTPServer {
    static final String DEFAULT_FILE = "index.html";
    static final String FILE_NOT_FOUND = "404.html";
    static final String METHOD_NOT_SUPPORTED = "no_support.html";
    static final int PORT = 8080;

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(PORT);

            System.out.println("Server started.\nListening for connections on port: " + PORT + " ...\n");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                HttpRequestHandler requestHandler = new HttpRequestHandler(clientSocket);
                Thread thread = new Thread(requestHandler);
                thread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static class HttpRequestHandler implements Runnable {
        private Socket clientSocket;

        public HttpRequestHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try {
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                DataOutputStream outToClient = new DataOutputStream(clientSocket.getOutputStream());

                String requestLine = inFromClient.readLine();
                System.out.println("Request: " + requestLine);

                String[] requestParts = requestLine.split(" ");
                String method = requestParts[0];
                String resourcePath = requestParts[1];

                if (method.equals("GET") || method.equals("HEAD")) {
                    String filePath = DEFAULT_FILE;
                    if (!resourcePath.equals("/")) {
                        filePath = resourcePath.substring(1);
                    }

                    File file = new File(filePath);

                    if (file.exists()) {
                        sendResponseHeader(outToClient, 200, file.length(), getContentType(filePath));

                        if (method.equals("GET")) {
                            FileInputStream fileInputStream = new FileInputStream(file);
                            byte[] buffer = new byte[1024];
                            int bytesRead;
                            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                                outToClient.write(buffer, 0, bytesRead);
                            }
                            fileInputStream.close();
                        }
                    } else {
                        File notFoundFile = new File(FILE_NOT_FOUND);
                        sendResponseHeader(outToClient, 404, notFoundFile.length(), getContentType(FILE_NOT_FOUND));
                        FileInputStream fileInputStream = new FileInputStream(notFoundFile);
                        byte[] buffer = new byte[1024];
                        int bytesRead;
                        while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                            outToClient.write(buffer, 0, bytesRead);
                        }
                        fileInputStream.close();
                    }
                } else {
                    File notSupportedFile = new File(METHOD_NOT_SUPPORTED);
                    sendResponseHeader(outToClient, 501, notSupportedFile.length(), getContentType(METHOD_NOT_SUPPORTED));
                    FileInputStream fileInputStream = new FileInputStream(notSupportedFile);
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                        outToClient.write(buffer, 0, bytesRead);
                    }
                    fileInputStream.close();
                }

                outToClient.close();
                inFromClient.close();
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private void sendResponseHeader(DataOutputStream outToClient, int statusCode, long contentLength, String contentType) throws IOException {
            outToClient.writeBytes("HTTP/1.1 " + statusCode + " " + getResponseStatus(statusCode) + "\r\n");
            outToClient.writeBytes("Content-Length: " + contentLength + "\r\n");
            outToClient.writeBytes("Content-Type: " + contentType + "\r\n");
            outToClient.writeBytes("\r\n");
        }

        private String getResponseStatus(int statusCode) {
            switch (statusCode) {
                case 200:
                    return "OK";
                case 404:
                    return "Not Found";
                case 501:
                    return "Not Implemented";
                default:
                    return "Unknown";
            }
        }

        private String getContentType(String filePath) {
            if (filePath.endsWith(".html") || filePath.endsWith(".htm")) {
                return "text/html";
            } else {
                return "application/octet-stream";
            }
        }
    }
}
