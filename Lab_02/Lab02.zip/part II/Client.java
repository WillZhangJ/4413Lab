import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        // Check if host and port number are provided as command line arguments
        if (args.length < 2) {
            System.out.println("Usage: java Client <host> <port>");
            System.exit(1);
        }

        String host = args[0];
        int port = Integer.parseInt(args[1]);

        try {
            Socket clientSocket = new Socket(host, port);

            BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());

            String serverResponse;

            while (true) {
                String userInput = inFromUser.readLine();
                outToServer.writeBytes(userInput + '\n');

                if (userInput.equalsIgnoreCase("quit")) {
                    break;
                }

                StringBuilder responseBuilder = new StringBuilder();
                while (!(serverResponse = inFromServer.readLine()).isEmpty()) {
                    responseBuilder.append(serverResponse).append('\n');
                }
                System.out.println("Server response:\n" + responseBuilder.toString());
            }

            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
