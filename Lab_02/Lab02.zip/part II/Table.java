import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;


/************************************************
this class implements database, storing client info
*************************************************/

public class Table {
    private final Map<String, String> clientMap;

    public Table() {
        clientMap = new HashMap<>();
    }

    public synchronized String register(String name, String group) {
        if (clientMap.containsKey(name)) {
            return name + " registration unsuccessful, name already exists!";
        } else {
            clientMap.put(name, group);
            return name + " registered successfully";
        }
    }

    public synchronized String query(String group) {
        StringBuilder result = new StringBuilder();
        for (Map.Entry<String, String> entry : clientMap.entrySet()) {
            String name = entry.getKey();
            String clientGroup = entry.getValue();
            if (group.equals("all") || group.equals(clientGroup)) {
                result.append(name).append(" ").append(clientGroup).append("\n");
            }
        }
        return result.toString();
    }

    public synchronized String quit(Socket socket) {
        String disconnectedClient = "";
        for (Map.Entry<String, String> entry : clientMap.entrySet()) {
            String name = entry.getKey();
            if (socket.getInetAddress().equals(socket.getInetAddress())) {
                disconnectedClient = name;
                break;
            }
        }
        if (!disconnectedClient.isEmpty()) {
            clientMap.remove(disconnectedClient);
            return disconnectedClient + " has disconnected";
        }
        return "";
    }
}
 // end of class
