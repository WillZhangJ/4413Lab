

/**
   This program demonstrates how to use a socket to communicate
   with a web server.  
*/
import java.io.*;
import java.net.*;

public class HttpClient {
    public static void main(String[] args) {
        // Check if hostname and resource path are provided as command line arguments
        if (args.length < 2) {
            System.out.println("Usage: java HttpClient <hostname> <resource path>");
            System.exit(1);
        }

        String hostname = args[0];
        String resourcePath = args[1];

        try {
            // Open socket
            final int HTTP_PORT = 80;
            Socket socket = new Socket(hostname, HTTP_PORT);

            // Get streams
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter outToServer = new PrintWriter(socket.getOutputStream(), true);

            // Send HTTP request header
            outToServer.println("GET " + resourcePath + " HTTP/1.1");
            outToServer.println("Host: " + hostname);
            outToServer.println();

            // Read and display response
            String line;
            while ((line = inFromServer.readLine()) != null) {
                System.out.println(line);
            }

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}



