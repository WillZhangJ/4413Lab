import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.Arrays;

public class ProcessorImpl extends UnicastRemoteObject  implements Processor {
	// Implementations must have an explicit constructor
    	public ProcessorImpl() throws RemoteException {
		  super();
	    }
	 

        public String upper(String s) throws RemoteException
        {
          return s.toUpperCase();
        }

        public String reverse(String s) throws RemoteException {
          StringBuilder sb = new StringBuilder(s);
          return sb.reverse().toString();
      }

        public String sort(String s) throws RemoteException
        {
          char[] chars = s.toCharArray();
          Arrays.sort(chars);
          return new String(chars);
        }

        public boolean isPalindrome(String s) throws RemoteException
        {
          StringBuilder sb = new StringBuilder(s);
          String reversed = sb.reverse().toString();
          return s.equalsIgnoreCase(reversed);
        }




}
