import java.rmi.registry.Registry; 
import java.rmi.registry.LocateRegistry; 
import java.rmi.RemoteException; 
import java.rmi.server.UnicastRemoteObject; 

public class ServerRMI {
    public static void main(String args[]) {
      try {
        // Create an instance of the remote object
        ProcessorImpl processor = new ProcessorImpl();

        // Export the remote object to make it available for incoming remote calls
        Processor stub = (Processor) UnicastRemoteObject.exportObject(processor, 0);

        // Obtain a reference to the registry
        Registry registry = LocateRegistry.getRegistry();

        // Bind the remote object's stub in the registry
        registry.bind("Processor", stub);

        System.out.println("Server ready");
    } catch (Exception e) {
        System.err.println("Server exception: " + e.toString());
        e.printStackTrace();
    }

  }

}
