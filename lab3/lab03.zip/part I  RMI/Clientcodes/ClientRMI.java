import java.rmi.registry.LocateRegistry; 
import java.rmi.registry.Registry; 
import java.io.*;
import java.util.Scanner;


public class ClientRMI{

      public static void main(String[] args) {
        try {
          // Obtain a reference to the registry
          Registry registry = LocateRegistry.getRegistry();

          // Look up the remote object from the registry
          Processor processor = (Processor) registry.lookup("Processor");

          Scanner scanner = new Scanner(System.in);

          while (true) {
              System.out.println("Enter your string:");
              String input = scanner.nextLine();

              if (input.equals("stop"))
                  break;

              // Invoke remote methods on the remote object
              String upperCase = processor.upper(input);
              String sorted = processor.sort(input);
              String reversed = processor.reverse(input);
              boolean isPalindrome = processor.isPalindrome(input);

              System.out.println("upper: " + upperCase);
              System.out.println("sort:  " + sorted);
              System.out.println("rever: " + reversed);
              System.out.println("isPanl: " + isPalindrome);
          }
      } catch (Exception e) {
          System.err.println("Client exception: " + e.toString());
          e.printStackTrace();
      }
  
  }
}
