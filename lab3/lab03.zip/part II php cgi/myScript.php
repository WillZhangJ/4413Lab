<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Form Submission Result</title>
  <link href="FormsInput.css" rel="stylesheet">
</head>
<body>
  <div class="box">
    <h2>Form Submission Result</h2>
    <?php
    // Check if form data was submitted
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
      // Retrieve form field values
      $firstName = $_GET["firstName"];
      $lastName = $_GET["lastName"];
      $email = $_GET["email"];
      $program = $_GET["program"];
      $year = $_GET["year"];
      $hobbies = isset($_GET["hobby"]) ? $_GET["hobby"] : [];
      $comment = $_GET["comment"];

      // Output the form data
      echo "<p><span class=\"fieldName\">First Name:</span> $firstName</p>";
      echo "<p><span class=\"fieldName\">Last Name:</span> $lastName</p>";
      echo "<p><span class=\"fieldName\">Email:</span> $email</p>";
      echo "<p><span class=\"fieldName\">Program:</span> $program</p>";
      echo "<p><span class=\"fieldName\">Year:</span> $year</p>";
      echo "<p><span class=\"fieldName\">Hobbies:</span> " . implode(", ", $hobbies) . "</p>";
      echo "<p><span class=\"fieldName\">Comment:</span> $comment</p>";
    } else {
      echo "<p>Form data not submitted.</p>";
    }
    ?>
  </div>
</body>
</html>
