// put your JS functions here
	
function validateForm() {
    // First Name
    var firstName = document.forms[0].firstName.value.trim();
    if (firstName === '') {
      alert('First name should be filled out');
      document.forms[0].firstName.focus();
      return false;
    }
    // Last Name
    var lastName = document.forms[0].lastName.value.trim();
    if (lastName === '') {
      alert('Last name should be filled out');
      document.forms[0].lastName.focus();
      return false;
    }
    // Password
    var password = document.forms[0].password.value.trim();
    if (password === '') {
      alert('Password should be filled out');
      document.forms[0].password.focus();
      return false;
    }
    // Email 
    var email = document.forms[0].email.value.trim();
    if (email === '') {
      alert('Email should be filled out');
      document.forms[0].email.focus();
      return false;
    }
    // Email format
    var emailFormat = /^[a-zA-Z0-9!-\/=?#\$%&'\*\+\^_`\{\|\}~]+@[a-zA-Z0-9\-]+(\.[a-zA-Z]{2,3})$/;
    if (!emailFormat.test(email)) {
      alert('Email format invalid');
      document.forms[0].email.focus();
      return false;
    }
    // Hobby selection
    var hobbies = document.getElementsByName('hobby[]');
    var isHobbySelected = false;
    for (var i = 0; i < hobbies.length; i++) {
      if (hobbies[i].checked) {
        isHobbySelected = true;
        break;
      }
    }
    if (!isHobbySelected) {
      alert('At least one hobby should be selected');
      return false;
    }
    // Course code
    var courseCode = document.forms[0].course.value.trim();
    if (courseCode !== '') {
      var courseCodeFormat = /^EECS\d{4}$/;
      if (!courseCodeFormat.test(courseCode)) {
        alert('Invalid course code. Examples of valid course codes: EECS1012, EECS2030');
        document.forms[0].course.focus();
        return false;
      }
      if (courseCode !== courseCode.toUpperCase()) {
        alert('Course code should be entered in capital letters (e.g., EECS1012)');
        document.forms[0].course.focus();
        return false;
      }
    }
    return true;
  }
  
function toggleOtherProgramField(selectElement) {
    var otherProgramField = document.getElementById("otherProgramField");
    if (selectElement.value === "OTHER") {
      otherProgramField.style.display = "inline"; 
      otherProgramField.focus(); 
    } else {
      otherProgramField.style.display = "none"; 
    }
  }
  
function toggleLogo() {
    var logo = document.getElementById('im');
    if (logo.getAttribute('src') === 'images/logo/york.png') {
      logo.setAttribute('src', 'images/logo/LAS.png');
    } else {
      logo.setAttribute('src', 'images/logo/york.png');
    }
  }
  
function changeBackgroundColor() {
    var boxElement = document.getElementById("box");
    boxElement.style.backgroundColor = 'lightblue';
  }

  

  
  