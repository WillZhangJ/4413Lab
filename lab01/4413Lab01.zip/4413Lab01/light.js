/* 4413 23Su Task 1 - write your code here */

function lightOn(lightNumber) {
    var im = document.getElementById('light');
    var ma = document.getElementById('message');
  
    switch (lightNumber) {
      case 'A':
        im.setAttribute('src', 'images/light/light_1.jpg');
        ma.innerHTML = 'light #1 is on';
        break;
      case 'B':
        im.setAttribute('src', 'images/light/light_2.jpg');
        ma.innerHTML = 'Light #2 is on';
        break;
      case 'C':
        im.setAttribute('src', 'images/light/light_3.jpg');
        ma.innerHTML = 'Light #3 is on';
        break;
      case 'D':
        im.setAttribute('src', 'images/light/light_4.jpg');
        ma.innerHTML = 'Light #4 is on';
        break;
      case 'E':
        im.setAttribute('src', 'images/light/light_5.jpg');
        ma.innerHTML = 'Light #5 is on';
        break;
      case 'OFF':
        im.setAttribute('src', 'images/light/light_0.jpg');
        ma.innerHTML = 'All lights are off';
        break;
      default:
        // Chunxin Zhang 215965585
        break;
    }
  }
  

 