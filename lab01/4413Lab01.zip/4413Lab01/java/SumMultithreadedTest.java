import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Date;

public class SumMultithreadedTest {

    public static void main(String[] args) {
        int[] mynums = new int[]{7, 3, 5, 6, 8, 15, 9, 3, 10};

        // Create two instances of SumThread class, give them name "sum thread A", "sum thread B",
        // give them the array and the range. One will work on the first half of the array,
        // another will work on the second half of the array
        SumThread sumThreadA = new SumThread("sum thread A", mynums, 0, mynums.length / 2);
        SumThread sumThreadB = new SumThread("sum thread B", mynums, mynums.length / 2, mynums.length);

        // Create two instances of MaxThread class, give them name "max thread X", "max thread Y",
        // give them the array and the range. One will work on the first half of the array,
        // another will work on the second half of the array
        MaxThread maxThreadX = new MaxThread("max thread X", mynums, 0, mynums.length / 2);
        MaxThread maxThreadY = new MaxThread("max thread Y", mynums, mynums.length / 2, mynums.length);

        // Start the 4 threads so they work in parallel
        sumThreadA.start();
        sumThreadB.start();
        maxThreadX.start();
        maxThreadY.start();

        try {
            // Wait for the 4 threads to finish
            sumThreadA.join();
            sumThreadB.join();
            maxThreadX.join();
            maxThreadY.join();

            // Retrieve the results
            int sum = sumThreadA.getSum() + sumThreadB.getSum();
            int max = Math.max(maxThreadX.getMax(), maxThreadY.getMax());

            System.out.println("Sum: " + sum + ", Max: " + max);
            Date date = new Date();
            System.out.println(date);

            // Store the result data in an instance of SumMaxResult class
            SumMaxResult result = new SumMaxResult(mynums, max, sum);

            // Write the object to a disk file "result.txt"
            FileOutputStream fileOut = new FileOutputStream("result.txt");
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
            objectOut.writeObject(result);
            objectOut.close();
            fileOut.close();

            System.out.println("Writing success");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
