import java.util.Arrays;

class MaxThread extends Thread {
    private int[] array;
    private int max;

    public MaxThread(int[] array) {
        this.array = array;
        this.max = Integer.MIN_VALUE;
    }

    @Override
    public void run() {
        for (int num : array) {
            if (num > max) {
                max = num;
            }
        }
        System.out.println("max thread " + getName() + " finish");
    }

    public int getMax() {
        return max;
    }
}
