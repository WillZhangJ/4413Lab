// this class retrieve the results from the disk file
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Arrays;

class Depersist {
    public static void main(String[] args) {
        try {
            // Open the file "result.txt" and retrieve the SumMaxResult object
            FileInputStream fileIn = new FileInputStream("result.txt");
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);
            SumMaxResult result = (SumMaxResult) objectIn.readObject();
            objectIn.close();
            fileIn.close();

            // Output the attributes of the object
            int[] arr = result.getArr();
            int max = result.getMax();
            int sum = result.getSum();
            System.out.println("Array: " + Arrays.toString(arr));
            System.out.println("Sum: " + sum);
            System.out.println("Max: " + max);
            System.out.println(result.getDate());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


 