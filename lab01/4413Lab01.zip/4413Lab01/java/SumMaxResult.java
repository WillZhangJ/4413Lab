import java.io.Serializable;
import java.util.Date;

class SumMaxResult implements Serializable {
    private int[] arr;      // the array operated on
    private int max;        // max value
    private int sum;        // sum value
    private Date date;      // result created date/time

    public SumMaxResult(int[] arr, int max, int sum) {
        this.arr = arr;
        this.max = max;
        this.sum = sum;
        this.date = new Date();
    }

    public int[] getArr() {
        return arr;
    }

    public int getMax() {
        return max;
    }

    public int getSum() {
        return sum;
    }

    public Date getDate() {
        return date;
    }
}
