/**
 * This thread finds the sum of values of a subsection of an given array.
 *  
 */
 

 class SumThread extends Thread {
    private String name;   // name of the thread
    private int low, hi;   // range of array from low to hi, [low, hi) includes low but does not include hi
    private int[] arr;     // array to be searched
    private int sum = 0;   // store results

    public SumThread(String name, int[] arr, int low, int hi) {
        this.name = name;
        this.arr = arr;
        this.low = low;
        this.hi = hi;
    }

    public int getSum() {
        return sum;
    }

    public void run() {
        for (int i = low; i < hi; i++) {
            sum += arr[i];
        }
        System.out.println(this.name + " finish");
    }
}


// create a similar class called MaxThread.java, which finds the max value in a subsection of an given array.
class MaxThread extends Thread {
    private String name;   // name of the thread
    private int low, hi;   // range of array from low to hi, [low, hi) includes low but does not include hi
    private int[] arr;     // array to be searched
    private int max = Integer.MIN_VALUE;   // store results

    public MaxThread(String name, int[] arr, int low, int hi) {
        this.name = name;
        this.arr = arr;
        this.low = low;
        this.hi = hi;
    }

    public int getMax() {
        return max;
    }

    public void run() {
        for (int i = low; i < hi; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        System.out.println(this.name + " finish");
    }
}
